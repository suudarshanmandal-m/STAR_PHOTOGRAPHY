import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { createServer } from "http";
import helmet from "helmet";
import compression from "compression";
import rateLimit from "express-rate-limit";
import hpp from "hpp";
import morgan from "morgan";
import winston from "winston";

// ============================================
// SECURITY HARDENING
// ============================================

// Winston Logger Configuration
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || "info",
  format: winston.format.combine(
    winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { service: "star-photography" },
  transports: [
    new winston.transports.File({ filename: "error.log", level: "error" }),
    new winston.transports.File({ filename: "combined.log" }),
  ],
});

if (process.env.NODE_ENV !== "production") {
  logger.add(
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      ),
    })
  );
}

const app = express();

// Helmet Security Headers
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        imgSrc: ["'self'", "data:", "https://images.unsplash.com"],
        connectSrc: ["'self'"],
      },
    },
    hsts: {
      maxAge: 31536000,
      includeSubDomains: true,
      preload: true,
    },
    frameguard: {
      action: "deny",
    },
    referrerPolicy: {
      policy: "strict-origin-when-cross-origin",
    },
    xssFilter: true,
    noSniff: true,
  })
);

// Compression Middleware
app.use(compression());

// Hide X-Powered-By Header
app.disable("x-powered-by");

// HTTP Parameter Pollution Protection
app.use(hpp());

// Morgan Request Logging (Production-safe)
const morganFormat = process.env.NODE_ENV === "production" ? "combined" : "dev";
app.use(
  morgan(morganFormat, {
    skip: (req) => req.path === "/health" || req.path === "/metrics",
    stream: {
      write: (message) => logger.info(message.trim()),
    },
  })
);

// Validate Environment Variables on Startup
const requiredEnvVars = ["DATABASE_URL"];
const missingEnvVars = requiredEnvVars.filter((v) => !process.env[v]);
if (missingEnvVars.length > 0) {
  logger.error(`Missing required environment variables: ${missingEnvVars.join(", ")}`);
  process.exit(1);
}

logger.info("Server starting with security hardening enabled");

// Rate Limiting Configuration
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: "Too many requests from this IP, please try again later.",
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.path === "/health",
  handler: (req, res) => {
    logger.warn(`Rate limit exceeded for IP: ${req.ip}`);
    res.status(429).json({
      message: "Too many requests, please try again later.",
    });
  },
});

const uploadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: "Too many upload requests from this IP, please try again later.",
  skip: (req) => req.path !== "/api/upload",
});

app.use("/api", limiter);
app.use("/api/upload", uploadLimiter);

const httpServer = createServer(app);

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

// Body Parser with Size Limits
app.use(
  express.json({
    limit: "5mb",
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  })
);

app.use(
  express.urlencoded({
    extended: false,
    limit: "5mb",
  })
);

// CORS Configuration
const allowedOrigins = (process.env.ALLOWED_ORIGINS || "http://localhost:3000").split(",");
app.use((req, res, next) => {
  const origin = req.headers.origin as string | undefined;
  if (origin && allowedOrigins.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Credentials", "true");
  }
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") {
    return res.sendStatus(200);
  }
  next();
});

// Logging Function
export function log(message: string, source = "express") {
  if (process.env.NODE_ENV === "production") {
    logger.info(message, { source });
  } else {
    const formattedTime = new Date().toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    });
    console.log(`${formattedTime} [${source}] ${message}`);
  }
}

export { logger };

// Request Timing and Logging Middleware
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api") && path !== "/api/health" && path !== "/api/metrics") {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse && process.env.NODE_ENV !== "production") {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      log(logLine);
    }
  });

  next();
});

// Graceful Shutdown Handler
process.on("SIGTERM", () => {
  logger.info("SIGTERM signal received: closing HTTP server");
  httpServer.close(() => {
    logger.info("HTTP server closed");
    process.exit(0);
  });
});

(async () => {
  logger.info("Registering API routes");
  await registerRoutes(httpServer, app);

  // Global Error Handler Middleware
  app.use((err: any, _req: Request, res: Response, next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    // Log error with full details
    logger.error("Internal Server Error", {
      status,
      message,
      stack: process.env.NODE_ENV !== "production" ? err.stack : undefined,
      url: _req.url,
      method: _req.method,
    });

    if (res.headersSent) {
      return next(err);
    }

    // Never expose stack trace in production
    const responseMessage =
      process.env.NODE_ENV === "production" ? "Internal Server Error" : message;

    return res.status(status).json({ message: responseMessage });
  });

  // Health Check Endpoint
  app.get("/health", (_req, res) => {
    res.status(200).json({
      status: "ok",
      uptime: process.uptime(),
      timestamp: Date.now(),
    });
  });

  // Metrics Endpoint
  app.get("/metrics", (_req, res) => {
    const memUsage = process.memoryUsage();
    res.status(200).json({
      uptime: process.uptime(),
      memory: {
        heapUsed: Math.round(memUsage.heapUsed / 1024 / 1024) + " MB",
        heapTotal: Math.round(memUsage.heapTotal / 1024 / 1024) + " MB",
        rss: Math.round(memUsage.rss / 1024 / 1024) + " MB",
      },
      timestamp: Date.now(),
    });
  });

  // Setup Vite in development or static serving in production
  // Important: do this after all other routes so catch-all doesn't interfere
  if (process.env.NODE_ENV === "production") {
    logger.info("Serving static assets from production build");
    serveStatic(app);
  } else {
    logger.info("Setting up Vite dev server");
    const { setupVite } = await import("./vite");
    await setupVite(httpServer, app);
  }

  // Determine port from environment or use default
  // Only the specified port is not firewalled
  const port = parseInt(process.env.PORT || "5000", 10);
  if (isNaN(port) || port < 1 || port > 65535) {
    logger.error(`Invalid port number: ${port}`);
    process.exit(1);
  }
  httpServer.listen(
    {
      port,
      host: "0.0.0.0",
      reusePort: true,
    },
    () => {
      log(`Server started successfully on port ${port}`);
      logger.info(`Environment: ${process.env.NODE_ENV || "development"}`);
      logger.info(`Security hardening: ENABLED`);
    },
  );
})().catch((err) => {
  logger.error("Fatal error during startup", { error: err });
  process.exit(1);
});
