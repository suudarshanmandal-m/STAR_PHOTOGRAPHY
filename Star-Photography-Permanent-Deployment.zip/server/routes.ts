import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { logger } from "./index";

// Input Sanitization Helper
function sanitizeInput(obj: any): any {
  if (typeof obj !== "object" || obj === null) {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map(sanitizeInput);
  }

  const sanitized: any = {};
  for (const [key, value] of Object.entries(obj)) {
    // Prevent NoSQL injection patterns
    if (key.startsWith("$") || key.includes(".")) {
      logger.warn(`Suspicious key detected in input: ${key}`);
      continue;
    }
    sanitized[key] = sanitizeInput(value);
  }
  return sanitized;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post(api.contact.create.path, async (req, res) => {
    try {
      // Sanitize input to prevent NoSQL injection
      const sanitizedBody = sanitizeInput(req.body);
      const input = api.contact.create.input.parse(sanitizedBody);
      
      // Log upload attempt
      logger.info("Contact message creation attempt", {
        email: input.email,
        ip: req.ip,
      });
      
      const message = await storage.createContactMessage(input);
      res.status(201).json(message);
    } catch (err) {
      if (err instanceof z.ZodError) {
        logger.warn("Validation error on contact creation", {
          errors: err.errors,
          ip: req.ip,
        });
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join("."),
        });
      }
      logger.error("Error creating contact message", { error: err });
      return res.status(500).json({ message: "Internal Server Error" });
    }
  });

  return httpServer;
}
