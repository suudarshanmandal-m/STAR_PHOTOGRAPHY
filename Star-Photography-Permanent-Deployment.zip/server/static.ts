import express, { type Express } from "express";
import fs from "fs";
import path from "path";

export function serveStatic(app: Express) {
  const distPath = path.resolve(__dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`,
    );
  }

  // Serve static files with Cache-Control headers
  app.use(
    express.static(distPath, {
      maxAge: "1d", // Cache static assets for 1 day
      etag: false, // Disable etag for better cache control
      setHeaders: (res, filePath) => {
        // Cache immutable assets (with hash in filename) for 1 year
        if (/\.[a-f0-9]{8}\.(js|css|woff2?)$/.test(filePath)) {
          res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
        } else {
          // Cache other assets for 1 day
          res.setHeader("Cache-Control", "public, max-age=86400");
        }
      },
    })
  );

  // Fall through to index.html if the file doesn't exist (SPA routing)
  app.use("/{*path}", (_req, res) => {
    res.setHeader("Cache-Control", "public, max-age=3600"); // Cache index.html for 1 hour
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}
