# Railway Deployment Guide for Star Photography Project

This guide outlines the steps to deploy the Star Photography project on Railway.

## 1. Project Structure

The project is a full-stack application with a client (React/Vite) and a server (Express.js). Railway will automatically detect the `package.json` and `railway.json` files to configure the deployment.

## 2. Environment Variables

Railway allows you to manage environment variables through its dashboard. You will need to set the following variables:

```
DATABASE_URL=your_postgresql_connection_string
ALLOWED_ORIGINS=https://your-railway-domain.railway.app,https://your-custom-domain.com
NODE_ENV=production
PORT=8080
LOG_LEVEL=info
```

**Important Notes:**

*   Replace `your_postgresql_connection_string` with the connection string to your PostgreSQL database. Railway offers managed PostgreSQL databases that you can easily provision and connect.
*   Replace `https://your-railway-domain.railway.app` with the actual URL of your application on Railway. If you use a custom domain, include that as well.
*   The `PORT` is set to `8080` in the `railway.json` file, which is a common default for Railway.

## 3. Deployment Steps

1.  **Connect to Git Repository**: Connect your Git repository (GitHub, GitLab, Bitbucket) to Railway.
2.  **New Project**: In Railway, create a new project and select "Deploy from Git Repo".
3.  **Select Repository**: Choose your repository and the branch you want to deploy.
4.  **Configure Environment Variables**: In the Railway dashboard for your project, navigate to the "Variables" tab and add the environment variables listed above.
5.  **Provision Database**: If you don't have a PostgreSQL database, you can provision one directly within Railway. Once provisioned, Railway will automatically inject the `DATABASE_URL` for you.
6.  **Deploy**: Railway will automatically detect the `railway.json` and `package.json` files, install dependencies, build the project, and start the server.

## 4. Post-Deployment

*   **Verify Application**: Access the URL provided by Railway for your application to ensure it loads correctly.
*   **Health Check**: The `railway.json` includes a health check path (`/health`), which Railway will use to monitor your application's health.
*   **Database Migrations**: If you have database migrations, you might need to run them manually using Railway's CLI or by adding a pre-deploy command. For Drizzle ORM, you would typically run `pnpm drizzle-kit push`.
