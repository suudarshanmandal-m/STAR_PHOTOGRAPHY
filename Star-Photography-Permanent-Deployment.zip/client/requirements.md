## Packages
framer-motion | Page transitions and scroll-triggered animations
react-hook-form | Managing form state and validation
@hookform/resolvers | Zod validation resolver for forms
embla-carousel-react | Testimonial carousel
embla-carousel-autoplay | Auto-playing for carousel

## Notes
- Tailwind Config: Standard configuration is fine, overriding CSS variables in index.css for the luxury theme.
- Images: Using high-quality Unsplash placeholders.
- API: Form posts to /api/contact using exact shared schemas.
