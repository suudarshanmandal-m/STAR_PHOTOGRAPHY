import { useMutation } from "@tanstack/react-query";
import { api, insertContactMessageSchema } from "@shared/routes";
import type { InsertContactMessage } from "@shared/schema";

export function useCreateContact() {
  return useMutation({
    mutationFn: async (data: InsertContactMessage) => {
      // Validate before sending using the shared schema
      const validated = insertContactMessageSchema.parse(data);
      
      const res = await fetch(api.contact.create.path, {
        method: api.contact.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || "Failed to send message");
      }

      const result = await res.json();
      return result;
    },
  });
}
