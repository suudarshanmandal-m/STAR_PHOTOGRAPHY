import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { Portfolio } from "@/components/Portfolio";
import { Services } from "@/components/Services";
import { Testimonials } from "@/components/Testimonials";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";
import { Helmet } from "react-helmet";

export default function Home() {
  return (
    <main className="bg-background min-h-screen">
      <Helmet>
        <title>STAR PHOTOGRAPHY | Wedding Photographer in Jhargram & Malbandhi</title>
        <meta name="description" content="STAR PHOTOGRAPHY by Suriya Sekhar Nanda. Capturing Emotions. Creating Timeless Memories. Specialized in wedding, pre-wedding, and event photography across Jhargram and Malbandhi." />
        <meta property="og:title" content="STAR PHOTOGRAPHY | Wedding Photographer in Jhargram & Malbandhi" />
        <meta property="og:description" content="Capturing Emotions. Creating Timeless Memories. Specialized in wedding and event photography." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://starphotography.replit.app" />
      </Helmet>
      <Navbar />
      <Hero />
      <About />
      <Portfolio />
      <Services />
      <Testimonials />
      <Contact />
      <Footer />
    </main>
  );
}
