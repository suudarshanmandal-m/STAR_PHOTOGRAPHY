import { Instagram, ArrowUp } from "lucide-react";

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-black pt-16 pb-8 border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center">
        
        <h2 className="text-3xl font-serif text-white tracking-[0.2em] mb-8">
          STAR <span className="text-primary italic">PHOTOGRAPHY</span>
        </h2>
        
        <div className="flex gap-6 mb-12">
          <a 
            href="https://instagram.com/itzsurya620" 
            target="_blank" 
            rel="noopener noreferrer"
            className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center text-white/60 hover:text-primary hover:border-primary hover:scale-110 transition-all duration-300"
            aria-label="Instagram"
          >
            <Instagram size={20} />
          </a>
        </div>

        {/* Divider */}
        <div className="w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent mb-8" />

        <div className="w-full flex flex-col md:flex-row items-center justify-between gap-4 text-xs tracking-wider uppercase text-white/40">
          <p>© {new Date().getFullYear()} STAR PHOTOGRAPHY</p>
          
          <p>
            Copywriting by <a href="https://sudarsha-n.vercel.app/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Sudarshan</a>
          </p>
        </div>
      </div>

      <button 
        onClick={scrollToTop}
        className="absolute bottom-8 right-4 md:right-8 w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/50 hover:text-primary hover:border-primary transition-all duration-300"
        aria-label="Scroll to top"
      >
        <ArrowUp size={16} />
      </button>
    </footer>
  );
}
