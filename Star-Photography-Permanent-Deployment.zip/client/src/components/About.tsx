import { motion } from "framer-motion";

export function About() {
  return (
    <section id="about" className="py-24 md:py-32 bg-background relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Image Column */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="relative"
          >
            <div className="aspect-[3/4] rounded-2xl overflow-hidden relative">
              {/* about section photographer holding camera placeholder */}
              <img
                src="https://pixabay.com/get/g5b56d0b3978477d4121d87ea3df0409f2d7971a661d3445c7838c54163c4a3ade2ac9b6317acfa9479642e9dd58937c52e9097c79972f2c0211903f00d88af86_1280.jpg"
                alt="Suriya Sekhar Nanda"
                className="w-full h-full object-cover filter grayscale hover:grayscale-0 transition-all duration-700"
              />
              <div className="absolute inset-0 ring-1 ring-inset ring-white/10 rounded-2xl" />
            </div>
            {/* Decorative Gold Elements */}
            <div className="absolute -bottom-6 -right-6 w-48 h-48 border border-primary/30 rounded-full z-[-1]" />
            <div className="absolute -top-6 -left-6 w-32 h-32 border border-primary/20 rounded-full z-[-1]" />
          </motion.div>

          {/* Content Column */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
          >
            <h2 className="text-4xl md:text-5xl font-serif text-white mb-6 relative inline-block group">
              The Artist Behind The Lens
              <span className="absolute -bottom-2 left-0 w-0 h-[2px] bg-primary transition-all duration-500 group-hover:w-full" />
            </h2>
            
            <p className="text-lg md:text-xl text-foreground/80 font-light leading-relaxed mb-8">
              <span className="text-primary font-semibold">STAR PHOTOGRAPHY</span> by Suriya Sekhar Nanda specializes in wedding, pre-wedding, and event photography across Jhargram and Malbandhi.
            </p>
            
            <p className="text-muted-foreground leading-relaxed mb-10">
              We believe that every love story is unique and deserves to be told with authenticity and elegance. With an eye for the cinematic and a heart for raw emotion, we turn fleeting moments into timeless heirlooms that you and your family will cherish for generations.
            </p>

            <div className="grid grid-cols-2 gap-8 mb-10 border-t border-white/10 pt-8">
              <div>
                <h4 className="text-3xl font-serif text-primary mb-2">50+</h4>
                <p className="text-sm uppercase tracking-widest text-muted-foreground">Weddings Covered</p>
              </div>
              <div>
                <h4 className="text-3xl font-serif text-primary mb-2">5+</h4>
                <p className="text-sm uppercase tracking-widest text-muted-foreground">Years Experience</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="h-[1px] w-12 bg-primary"></div>
              <p className="font-serif italic text-xl text-white/90">Suriya Sekhar Nanda</p>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
