import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import useEmblaCarousel from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";
import { Quote } from "lucide-react";

const testimonials = [
  {
    name: "Priya & Rahul",
    role: "Bride & Groom",
    text: "Suriya captured the soul of our wedding. Every picture feels like a beautifully directed movie scene. We couldn't have asked for a better team.",
  },
  {
    name: "Ananya & Dev",
    role: "Pre-Wedding Couple",
    text: "The dedication and creativity of Star Photography are unmatched. The pre-wedding shoot was so fun, and the results blew us away!",
  },
  {
    name: "The Sharma Family",
    role: "Event Clients",
    text: "Professional, punctual, and incredibly talented. The cinematic video brought tears to our eyes. Highly recommended for any luxury event.",
  }
];

export function Testimonials() {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true }, [Autoplay({ delay: 5000 })]);
  const [selectedIndex, setSelectedIndex] = useState(0);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
  }, [emblaApi, setSelectedIndex]);

  useEffect(() => {
    if (!emblaApi) return;
    emblaApi.on("select", onSelect);
  }, [emblaApi, onSelect]);

  return (
    <section className="py-24 bg-[#080808] border-y border-white/5 relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        
        <Quote className="mx-auto text-primary/30 w-16 h-16 mb-8" />
        
        <div className="overflow-hidden" ref={emblaRef}>
          <div className="flex">
            {testimonials.map((testimonial, idx) => (
              <div className="flex-[0_0_100%] min-w-0" key={idx}>
                <motion.div
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  className="px-4"
                >
                  <p className="text-xl md:text-3xl font-serif italic leading-relaxed text-white/90 mb-10">
                    "{testimonial.text}"
                  </p>
                  <h4 className="text-primary uppercase tracking-widest text-sm font-semibold">
                    {testimonial.name}
                  </h4>
                  <p className="text-muted-foreground text-xs uppercase tracking-wider mt-2">
                    {testimonial.role}
                  </p>
                </motion.div>
              </div>
            ))}
          </div>
        </div>

        {/* Dots */}
        <div className="flex justify-center gap-3 mt-12">
          {testimonials.map((_, idx) => (
            <button
              key={idx}
              onClick={() => emblaApi?.scrollTo(idx)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                idx === selectedIndex ? "bg-primary w-6" : "bg-white/20 hover:bg-white/40"
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>

      </div>
    </section>
  );
}
