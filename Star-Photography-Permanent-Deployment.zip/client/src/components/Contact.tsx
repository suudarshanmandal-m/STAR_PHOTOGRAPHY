import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { MapPin, Phone, Mail, Instagram, Loader2, CheckCircle2 } from "lucide-react";
import { insertContactMessageSchema } from "@shared/routes";
import { useCreateContact } from "@/hooks/use-contact";

type FormData = z.infer<typeof insertContactMessageSchema>;

export function Contact() {
  const [isSuccess, setIsSuccess] = useState(false);
  const contactMutation = useCreateContact();

  // Log errors only in development
  useEffect(() => {
    if (contactMutation.isError && process.env.NODE_ENV !== "production") {
      console.error("Contact submission error:", contactMutation.error);
    }
  }, [contactMutation.isError, contactMutation.error]);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(insertContactMessageSchema),
  });

  const onSubmit = async (data: FormData) => {
    try {
      await contactMutation.mutateAsync(data);
      setIsSuccess(true);
      reset();
      setTimeout(() => setIsSuccess(false), 5000);
    } catch (error) {
      // Error is handled by the mutation state (contactMutation.isError)
      // Development logging is handled in useEffect above
    }
  };

  return (
    <section id="contact" className="py-24 md:py-32 bg-background relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Info Column */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex flex-col justify-center"
          >
            <h2 className="text-4xl md:text-5xl font-serif text-white mb-6">
              Let's Create <br/>
              <span className="text-primary italic">Magic Together</span>
            </h2>
            <p className="text-muted-foreground mb-12 max-w-md leading-relaxed">
              Ready to document your story? Get in touch with us to discuss your vision, check availability, and tailor a custom package for your special day.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 rounded-full glass flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                  <MapPin size={20} />
                </div>
                <div>
                  <h4 className="text-white font-serif mb-1">Location</h4>
                  <p className="text-muted-foreground text-sm">Jhargram / Malbandhi, India</p>
                </div>
              </div>

              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 rounded-full glass flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                  <Phone size={20} />
                </div>
                <div>
                  <h4 className="text-white font-serif mb-1">Phone</h4>
                  <a href="tel:+919110041626" className="text-muted-foreground text-sm hover:text-primary transition-colors">
                    +91 9110041626
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 rounded-full glass flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                  <Mail size={20} />
                </div>
                <div>
                  <h4 className="text-white font-serif mb-1">Email</h4>
                  <a href="mailto:surajnanda891@gmail.com" className="text-muted-foreground text-sm hover:text-primary transition-colors">
                    surajnanda891@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 rounded-full glass flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                  <Instagram size={20} />
                </div>
                <div>
                  <h4 className="text-white font-serif mb-1">Instagram</h4>
                  <a 
                    href="https://instagram.com/itzsurya620" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-muted-foreground text-sm hover:text-primary transition-colors"
                  >
                    @itzsurya620
                  </a>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Form Column */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-card p-8 md:p-12 rounded-3xl"
          >
            {isSuccess ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="h-full flex flex-col items-center justify-center text-center py-12"
              >
                <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle2 className="text-primary w-10 h-10" />
                </div>
                <h3 className="text-2xl font-serif text-white mb-3">Message Sent!</h3>
                <p className="text-muted-foreground">
                  Thank you for reaching out. We will get back to you shortly.
                </p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm uppercase tracking-wider text-white/60 mb-2 ml-1">
                    Your Name
                  </label>
                  <input
                    {...register("name")}
                    type="text"
                    id="name"
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-4 text-white placeholder:text-white/20 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                    placeholder="John Doe"
                  />
                  {errors.name && <p className="text-destructive text-xs mt-2 ml-1">{errors.name.message}</p>}
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm uppercase tracking-wider text-white/60 mb-2 ml-1">
                    Email Address
                  </label>
                  <input
                    {...register("email")}
                    type="email"
                    id="email"
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-4 text-white placeholder:text-white/20 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                    placeholder="john@example.com"
                  />
                  {errors.email && <p className="text-destructive text-xs mt-2 ml-1">{errors.email.message}</p>}
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm uppercase tracking-wider text-white/60 mb-2 ml-1">
                    Message Details
                  </label>
                  <textarea
                    {...register("message")}
                    id="message"
                    rows={4}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-4 text-white placeholder:text-white/20 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all resize-none"
                    placeholder="Tell us about your event..."
                  />
                  {errors.message && <p className="text-destructive text-xs mt-2 ml-1">{errors.message.message}</p>}
                </div>

                {contactMutation.isError && (
                  <div className="text-destructive text-sm bg-destructive/10 p-3 rounded-lg border border-destructive/20">
                    <p>Failed to send message. Please try again.</p>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={contactMutation.isPending}
                  className="w-full btn-gold flex items-center justify-center gap-2 mt-4"
                >
                  {contactMutation.isPending ? (
                    <>
                      <Loader2 className="animate-spin" size={18} />
                      Sending...
                    </>
                  ) : (
                    "Send Inquiry"
                  )}
                </button>
              </form>
            )}
          </motion.div>

        </div>
      </div>
    </section>
  );
}
