# Render Deployment Guide for Star Photography Project

This guide outlines the steps to deploy the Star Photography project on Render.

## 1. Project Structure

The project is structured as a monorepo with a client (React/Vite) and a server (Express.js). The `render.yaml` file defines two services:

*   **star-photography-backend**: The Node.js Express server.
*   **star-photography-frontend**: The static React application.

## 2. Environment Variables

Render allows you to manage environment variables through its dashboard. You will need to set the following variables for the `star-photography-backend` service:

```
DATABASE_URL=your_postgresql_connection_string
ALLOWED_ORIGINS=https://your-frontend-domain.onrender.com,https://your-custom-domain.com
PORT=10000
NODE_ENV=production
LOG_LEVEL=info
```

**Important Notes:**

*   Replace `your_postgresql_connection_string` with the connection string to your PostgreSQL database. Render offers managed PostgreSQL databases that you can easily integrate.
*   Replace `https://your-frontend-domain.onrender.com` with the actual URL of your frontend service on Render. If you use a custom domain, include that as well.
*   The `PORT` is set to `10000` as per Render's requirements for web services.

## 3. Deployment Steps

1.  **Connect to Git Repository**: Connect your Git repository (GitHub, GitLab, Bitbucket) to Render.
2.  **Create a New Blueprint**: In Render, go to "Blueprints" and select "New Blueprint Instance". Choose your repository.
3.  **Review `render.yaml`**: Render will automatically detect and use the `render.yaml` file in your repository to create the services.
4.  **Configure Environment Variables**: For the `star-photography-backend` service, add the environment variables listed above in the Render dashboard.
5.  **Deploy**: Initiate the deployment. Render will build and deploy both your backend and frontend services.

## 4. Post-Deployment

*   **Verify Backend**: Check the logs of the `star-photography-backend` service for any errors. Access the `/health` endpoint (e.g., `https://your-backend-domain.onrender.com/health`) to ensure it's running.
*   **Verify Frontend**: Access the URL of your `star-photography-frontend` service to ensure the application loads correctly.
*   **Database Migrations**: If you have database migrations, you might need to run them manually via a Render Shell or a separate `job` service in your `render.yaml` (not included in the current `render.yaml`). For Drizzle ORM, you would typically run `pnpm drizzle-kit push`.
